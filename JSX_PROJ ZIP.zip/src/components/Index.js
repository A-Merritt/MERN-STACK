import React from 'react';

const Index = () => {
    return(
        <div className="index">
            <h1>Hello Dojo!</h1>
            <h3>Things I need to do:</h3>
            <li>Learn React</li>
            <li>Climb Mount Everest</li>
            <li>Run a Marathon</li>
            <li>Feed the Dogs</li>
        </div>
    )
}

export default Index